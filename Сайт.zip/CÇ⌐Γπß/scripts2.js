// Пример данных о продуктах
var products = [
  { name: "Комфортабельный двухэтажный дом", price: 22766, image: "1-3-1-768x432.jpg" },
  { name: "Двухэтажный дом с открытой террасой", price: 28669, image: "1-2-1-768x748.jpg" },
  { name: "Одноэтажный дом с баней", price: 25296, image: "1-1-1-768x427.jpg" },
  { name: "Уютный двухэтажный дом", price: 26516, image: "1-9-768x527.jpg" },
  { name: "Одноэтажный дом из светлого кирпича", price: 17499, image: "1-10-1-768x596.jpg" },
  { name: "Комфортный двухэтажный дом с крыльцом", price: 25717, image: "1-11-1-768x495.jpg" },
  { name: "Большой одноэтажный дом", price: 19815, image: "1-3-768x485.jpg" },
  { name: "Уютный двухэтажный дом с террасой", price: 32569, image: "1-4-768x432.jpg" },
  { name: "Одноэтажный дом с гаражом", price: 24050, image: "2-5-768x671.jpg" },
  { name: "Одноэтажный дом с террасой", price: 16231, image: "1-8-768x608.jpg" },
    ];
  
  // Функция для отображения каталога продуктов
  function renderCatalog() {
    var catalogElement = document.getElementById("catalog");
  
    for (var i = 0; i < products.length; i++) {
      var product = products[i];
  
      var productElement = document.createElement("div");
      productElement.classList.add("product");
  
      var imageElement = document.createElement("img");
      imageElement.src = product.image;
      productElement.appendChild(imageElement);
  
      var nameElement = document.createElement("p");
      nameElement.textContent = product.name;
      productElement.appendChild(nameElement);
  
      var priceElement = document.createElement("p");
      priceElement.textContent = "Цена: " + product.price;
      productElement.appendChild(priceElement);
  
      catalogElement.appendChild(productElement);
    }
  }
  
  // Вызов функции для отображения каталога продуктов
  renderCatalog();