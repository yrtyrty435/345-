// Обработчик события отправки формы
document.getElementById("registrationForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Предотвращаем перезагрузку страницы
    
    // Получаем значения полей ввода
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var username = document.getElementById("username").value;
    
    
    // Здесь вы можете выполнить проверки на вводимые данные, например, проверку на длину пароля или на доступность логина.
    // Вы можете использовать AJAX запрос для отправки данных на сервер и создания нового аккаунта.
    
    // Выводим сообщение об успешной регистрации
    alert("Вы успешно зарегистрированы!");
    
    // Очищаем поля ввода
    document.getElementById("username").value = "";
    document.getElementById("password").value = "";
  });